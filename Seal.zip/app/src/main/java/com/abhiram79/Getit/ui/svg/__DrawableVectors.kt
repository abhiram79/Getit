package com.junkfood.seal.ui.svg

public object DynamicColorImageVectors
